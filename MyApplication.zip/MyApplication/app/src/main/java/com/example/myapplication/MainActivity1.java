package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.TimePicker;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.databinding.MainActivity1Binding;
import com.google.android.material.textfield.TextInputEditText;

import org.jetbrains.annotations.Nullable;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import kotlin.jvm.internal.Intrinsics;


public final class MainActivity1 extends AppCompatActivity {
    private MainActivity1Binding binding;

    @RequiresApi(api = Build.VERSION_CODES.O)
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainActivity1Binding var10001 = MainActivity1Binding.inflate(this.getLayoutInflater());
        Intrinsics.checkNotNullExpressionValue(var10001, "ActivityMainBinding.inflate(layoutInflater)");
        this.binding = var10001;
        var10001 = this.binding;
        if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        this.setContentView((View)var10001.getRoot());
        this.createNotificationChannel();
        MainActivity1Binding var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        var10000.submitBtn.setOnClickListener((OnClickListener)(new OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            public final void onClick(View it) {
                MainActivity1.this.scheduleNotification();
            }
        }));
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private final void scheduleNotification() {
        Intent intent = new Intent(this.getApplicationContext(), Notif.class);
        MainActivity1Binding var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        TextInputEditText var8 = var10000.titleET;
        Intrinsics.checkNotNullExpressionValue(var8, "binding.titleET");
        String title = String.valueOf(var8.getText());
        var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        var8 = var10000.messageET;
        Intrinsics.checkNotNullExpressionValue(var8, "binding.messageET");
        String message = String.valueOf(var8.getText());
        intent.putExtra("titleExtra", title);
        intent.putExtra("messageExtra", message);
        @SuppressLint("WrongConstant") PendingIntent pendingIntent = PendingIntent.getBroadcast(this.getApplicationContext(), 1, intent, 201326592);
        Object var9 = this.getSystemService(Context.ALARM_SERVICE);
        if (var9 == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.app.AlarmManager");
        } else {
            AlarmManager alarmManager = (AlarmManager)var9;
            long time = this.getTime();
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME, time, pendingIntent);
            this.showAlert(time, title, message);
        }
    }

    private final void showAlert(long time, String title, String message) {
        Date date = new Date(time);
        DateFormat dateFormat = android.text.format.DateFormat.getLongDateFormat(this.getApplicationContext());
        DateFormat timeFormat = android.text.format.DateFormat.getTimeFormat(this.getApplicationContext());
        AlertDialog show = (new Builder((Context) this)).setTitle((CharSequence) "Notification Scheduled").setMessage((CharSequence)
                ("Title: " + title + "\nMessage: " + message + "\nAt: " + dateFormat.format(date) + " " + timeFormat.format(time))).setPositiveButton((CharSequence) "Okay",
                (DialogInterface.OnClickListener)null ).show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private final long getTime() {
        MainActivity1Binding var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        TimePicker var7 = var10000.timePicker;
        Intrinsics.checkNotNullExpressionValue(var7, "binding.timePicker");
        int minute = var7.getMinute();
        var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        var7 = var10000.timePicker;
        Intrinsics.checkNotNullExpressionValue(var7, "binding.timePicker");
        int hour = var7.getHour();
        var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        DatePicker var8 = var10000.datePicker;
        Intrinsics.checkNotNullExpressionValue(var8, "binding.datePicker");
        int day = var8.getDayOfMonth();
        var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        var8 = var10000.datePicker;
        Intrinsics.checkNotNullExpressionValue(var8, "binding.datePicker");
        int month = var8.getMonth();
        var10000 = this.binding;
        if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
        }

        var8 = var10000.datePicker;
        Intrinsics.checkNotNullExpressionValue(var8, "binding.datePicker");
        int year = var8.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day, hour, minute);
        Intrinsics.checkNotNullExpressionValue(calendar, "calendar");
        return calendar.getTimeInMillis();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private final void createNotificationChannel() {
        String name = "Notif Channel";
        String desc = "Description of the Channel";
        int importance = 3;
        @SuppressLint("WrongConstant") NotificationChannel channel = new NotificationChannel("channel1", (CharSequence)name, importance);
        channel.setDescription(desc);
        Object var10000 = this.getSystemService(Context.NOTIFICATION_SERVICE);
        if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.app.NotificationManager");
        } else {
            NotificationManager notificationManager = (NotificationManager)var10000;
            notificationManager.createNotificationChannel(channel);
        }
    }
}