package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {


    Button btn_continue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.textView10);

        String text = "Organize your workplace with ProA";
        SpannableString ss = new SpannableString(text);

        ForegroundColorSpan fcslime = new ForegroundColorSpan(Color.GREEN);
        ss.setSpan(fcslime, 28,33, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        textView.setText(ss);

        btn_continue=findViewById(R.id.btncontinue);

        btn_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),dashboard.class);
                startActivity(i);
            }
        });
    }
}