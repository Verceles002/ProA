package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class setalarm extends AppCompatActivity {
    EditText ethour;
    EditText etminute;
    Button setalarm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setalarm);

        ethour = findViewById(R.id.ethour);
        etminute = findViewById(R.id.etminute);
        setalarm = findViewById(R.id.btn_setalarm);

        setalarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hour = Integer.parseInt(ethour.getText().toString());
                int minute = Integer.parseInt(etminute.getText().toString());

                Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                intent.putExtra(AlarmClock.EXTRA_HOUR,hour);
                intent.putExtra(AlarmClock.EXTRA_MINUTES,minute);
                if(hour<=24 && minute<=60){
                    startActivity(intent);
                }

            }
        });
    }
}
