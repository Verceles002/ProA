package com.example.myapplication;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat.Builder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;



public final class Notif extends BroadcastReceiver {
    public static final int notificationID = 1;
    @NotNull
    public static final String channelID = "channel1";
    @NotNull
    public static final String titleExtra = "titleExtra";
    @NotNull
    public static final String messageExtra = "messageExtra";

    public void onReceive(@NotNull Context context, @NotNull Intent intent) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(intent, "intent");
        Notification var10000 = (new Builder(context, "channel1")).setSmallIcon(700000).setContentTitle((CharSequence)intent.getStringExtra("titleExtra")).setContentText((CharSequence)intent.getStringExtra("messageExtra")).build();
        Intrinsics.checkNotNullExpressionValue(var10000, "NotificationCompat.Build…ra))\n            .build()");
        Notification notification = var10000;
        Object var5 = context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (var5 == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.app.NotificationManager");
        } else {
            NotificationManager manager = (NotificationManager)var5;
            manager.notify(1, notification);
        }
    }
}
