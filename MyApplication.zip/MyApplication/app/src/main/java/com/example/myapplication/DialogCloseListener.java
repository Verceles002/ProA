package com.example.myapplication;

import android.content.DialogInterface;

public interface DialogCloseListener {
    void handleDialogClose(DialogInterface dialog);
//    void AdapterView(OnItemLongClickListener onItemLongClickListener);

//    void onItemLongClick(int position);
}